package com.ooad.assignment;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class BeginProcess {

	public static void main(String[] args) {
		Map<Integer,Map<Date,String>> GuardInfo = new HashMap<Integer, Map<Date, String>>();
		GuardInfoLoader loader = new GuardInfoLoader();
		GuradInfoAnalyser analysis = new GuradInfoAnalyser();
		GuardInfo = loader.LoadFromFile();
		analysis.loadData(GuardInfo);
	}
}