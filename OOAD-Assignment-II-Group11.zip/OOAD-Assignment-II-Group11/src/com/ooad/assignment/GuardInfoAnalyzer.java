package com.ooad.assignment;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class GuradInfoAnalyser {

	public void loadData(Map<Integer, Map<Date, String>> guardInfo) {
		HashMap<Integer,Map<Integer,GuardTimeTable>> GuardTimeByDate = new HashMap<Integer,Map<Integer,GuardTimeTable>>();
		int d = 0;
		int most_awake_guard = 0;
		int most_slept_guard = 0;
		int larger_work_time = 0;
		int larger_slept_time = 0;
		for (int id: guardInfo.keySet()){
			//System.out.println("Id = "+id);
			d = 0;
			Map<Date,String> tmp_map = guardInfo.get(id);
			for(Date k: tmp_map.keySet()) {
				if(tmp_map.get(k).contains("begins")) {
					GuardTimeTable tb = new GuardTimeTable();
					if(null != GuardTimeByDate.get(id)) {
						d = GuardTimeByDate.get(id).size()+1;
						tb.GuardShitStartTime(k);
						GuardTimeByDate.get(id).put(d, tb);
					}
					else {
						d++;
						Map<Integer,GuardTimeTable> tmp_table = new HashMap<Integer,GuardTimeTable>();
						tb.GuardShitStartTime(k);
						tmp_table.put(d, tb);
						GuardTimeByDate.put(id, tmp_table);
					}
				}
				else if(tmp_map.get(k).contains("End")){
					GuardTimeByDate.get(id).get(d).setShiftEndTime(k);
				}
				else if(tmp_map.get(k).contains("sleep")) {
					GuardTimeByDate.get(id).get(d).setSleepTime(k);
				}
				else if(tmp_map.get(k).contains("wakes")){
					GuardTimeByDate.get(id).get(d).setWakeUpTime(k);
				}
				else {
					System.out.println("Wrong Format");
				}
				//System.out.println(" k = "+k+" value = "+tmp_map.get(k));
			}		
		} 
		
		for(int id:GuardTimeByDate.keySet()){
			int total_work_time = 0;
			int total_slept_time = 0;
			int total_days = 0;
		
			System.out.println("\nID : "+id+" Report as follows ");
			for(int day:GuardTimeByDate.get(id).keySet()) {
				System.out.println("Day - "+day);
				total_days++;
				System.out.println("Shift Start time = "+GuardTimeByDate.get(id).get(day).ShiftStartTime);

System.out.println("Shift End time = "+GuardTimeByDate.get(id).get(day).ShiftEndTime);
				System.out.println("Total Slept Time = "+GuardTimeByDate.get(id).get(day).SleptTime);
				System.out.println("Total Work Time = "+GuardTimeByDate.get(id).get(day).Worktime);
				total_work_time =  total_work_time+(int)GuardTimeByDate.get(id).get(day).Worktime;
				total_slept_time = total_slept_time + (int)GuardTimeByDate.get(id).get(day).SleptTime;
			}
			System.out.println("Total days  = "+total_days);
			System.out.println("total_work_time = "+total_work_time+"; avg ="+total_work_time/total_days);
			System.out.println("Total Slept Time = "+total_slept_time+"; avg ="+total_slept_time/total_days);
			if(larger_work_time < (total_work_time/total_days)) {				
				larger_work_time = (total_work_time/total_days);
				most_awake_guard = id;
			}
		
			if(larger_slept_time < (total_slept_time/total_days)) {
				larger_slept_time = (total_slept_time/total_days);
				most_slept_guard = id;
			}
		}
		System.out.println("Most worked Gurad id = "+most_awake_guard);
		System.out.println("Most Slept Guard id = "+most_slept_guard);
	}

}