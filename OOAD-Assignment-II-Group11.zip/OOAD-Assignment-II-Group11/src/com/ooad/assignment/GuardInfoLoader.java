package com.ooad.assignment;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class GuardInfoLoader {
	public Map<Integer,Map<Date,String>> LoadFromFile() {
		LinkedHashMap<Integer,Map<Date, String>> map = new LinkedHashMap<Integer,Map<Date, String>>();
		BufferedReader reader;		
		int Guard_no = 0;
		int previous_Guard_no = -1;
		int l = 0;
		int line_no = 0;
		String job = "";
		String Time = "";
		String line = "";
		Date date = new Date();
		Date tmp_shift_start_date = new Date();
		List<Date> tmp_sleep_start_date = new ArrayList<Date>();
		List<Date> tmp_sleep_end_date = new ArrayList<Date>();
		try {
			reader = new BufferedReader(new FileReader("Input_FIle/Records.txt"));
			line = reader.readLine();
			while (line != null) {
				line_no++;
				line = line.trim();
				if(!"".equalsIgnoreCase(line)){
					String[] tmp = line.split(" ",-1);
					Map<Date, String> tmp_map = new HashMap<Date, String>();
					if(line.toLowerCase().contains("guard")) {
						if(line.contains("#")){
							String num = tmp[3].trim();
							num = num.replace("#", "");
							Guard_no = Integer.parseInt(num);
						}
						else {
							System.out.println("Error parsing the Guard id , please check the input file and the line # is "+ line_no);
							System.exit(1);
						}
					}
					if(map.get(Guard_no) != null) {
						tmp_map = map.get(Guard_no);
					}
					if(line.contains("[") && line.contains("]")){
						Time = line.substring(line.indexOf("[")+1,line.indexOf("]"));
						try {
							SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
							sdf.setLenient(false);

date=sdf.parse(Time);
						}
						catch(ParseException e){
							System.out.println("Error parsing the Date and time , please check the input file and the line # is "+ line_no);
							System.exit(1);
						}
					}
					else {
						System.out.println("Error parsing the Date time  , please check the input file and the line # is "+ line_no);
						System.exit(1);
					}
					if(tmp.length >= 4) {
						l = tmp.length;
						job = tmp[l-2]+tmp[l-1];
					}
					else {
						System.out.println("Error parsing the jobs  , please check the input file and the line # is "+ line_no);
						System.exit(1);
					}
					if(job.contains("begins") && previous_Guard_no > 0){
						map.get(previous_Guard_no).put(date, "ShiftEnd");
						CheckTheSleepTime(previous_Guard_no,tmp_shift_start_date,date,tmp_sleep_start_date,tmp_sleep_end_date);
						tmp_sleep_start_date = new ArrayList<Date>();
						tmp_sleep_end_date = new ArrayList<Date>();
					}
					if(job.contains("begins")){
						tmp_shift_start_date = date;
					}
					else if(job.contains("sleep")) {
						tmp_sleep_start_date.add(date);
					}
					else if(job.contains("wake")) {
						tmp_sleep_end_date.add(date);
					}
					else {
						System.out.println("Ill-informed job");
						System.exit(1);
					}
					if(null != tmp_map.get(date) && !"".equalsIgnoreCase(tmp_map.get(date))){
						Calendar cal = Calendar.getInstance();
						cal.setTime(date);
						long t= cal.getTimeInMillis();
						date=new Date(t + (2 * 60000));
						tmp_map.put(date, job);
					}
					else {
						tmp_map.put(date, job);
					}
					map.put(Guard_no, tmp_map);
					previous_Guard_no = Guard_no;
				}
				line = reader.readLine();				
			}
			reader.close();
			for (int id: map.keySet()){
				/*System.out.println("**** "+id);
				for(Date d: map.get(id).keySet()) {
					System.out.println(d+" => "+map.get(id).get(d));
				}*/


Map<Date,String> tmp = new TreeMap<Date, String>(map.get(id));
				/*for(Date d: tmp.keySet()) {
					System.out.println(d+" => "+tmp.get(d));
				}*/
				map.put(id, tmp);
			} 
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return map;
	}

	private void CheckTheSleepTime(int id,Date shiftStartTime, Date shiftEndTime,List<Date> sleepStartTime, List<Date> sleepEndTime) {
		/*System.out.println("************************");
		System.out.println("Id = "+id);
		System.out.println("shiftStartTime ="+shiftStartTime);
		System.out.println("shiftEndTime ="+shiftEndTime);
		System.out.println("Sleep Start time =");
		for(Date d : sleepStartTime)
			System.out.println("\t"+d);
		System.out.println("Sleep End time =");
		for(Date d : sleepEndTime)
			System.out.println("\t"+d);*/
		if(shiftEndTime.before(shiftStartTime)){
			System.out.println("Please check the input file for Shift Start time and End Time "+id);
			System.exit(1);
		}
		if(sleepStartTime.size() != sleepEndTime.size()) {
			System.out.println("Sleep count not matched with wake up counts for id : "+id+" Please check the input file");
			System.exit(1);
		}
		
		for(int i=0; i<sleepStartTime.size(); i++){
			if(i == 0) {
				if(sleepStartTime.get(i).before(shiftStartTime) || sleepStartTime.get(i).after(sleepEndTime.get(i))) {
					System.out.println("Sleep Start time not matched for id : " +id);
					System.exit(1);
				}
			}
			else {
				if(sleepStartTime.get(i).before(sleepEndTime.get(i-1)) || sleepStartTime.get(i).after(sleepEndTime.get(i))) {
					System.out.println("Sleep Start time not matched for id : " +id);
					System.exit(1);
				}
			}
		}
		
		for (int i =0; i<sleepEndTime.size(); i++) {
			if(i == (sleepEndTime.size()-1)) {
				if(sleepEndTime.get(i).before(sleepStartTime.get(i))) {
					System.out.println("Sleep End time not matched for id : " +id);
					System.exit(1);
				}
			}
			else {
if(sleepEndTime.get(i).before(sleepStartTime.get(i)) || sleepEndTime.get(i).after(sleepStartTime.get(i+1))) {
					System.out.println("Sleep End time not matched for id : " +id);
					System.exit(1);
				}
			}
		}
	}
}
