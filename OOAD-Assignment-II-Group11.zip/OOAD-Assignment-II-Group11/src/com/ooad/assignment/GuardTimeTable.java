package com.ooad.assignment;

import java.util.Calendar;
import java.util.Date;

public class GuardTimeTable {
	Date ShiftStartTime;
	Date ShiftEndTime;
	Date SleepStartTime;
	Date WakeupStartTime;
	long SleptTime = 0;
	long Worktime = 0;
	boolean isNewWakeupStartTime = true;
	
	public void GuardShitStartTime (Date startTime){
		ShiftStartTime = startTime;
		Calendar calendar = Calendar.getInstance();
	    calendar.setTime(startTime);
	    calendar.add(Calendar.HOUR_OF_DAY, 24);
		ShiftEndTime = calendar.getTime();
		Worktime = (ShiftEndTime.getTime() - ShiftStartTime.getTime()) / (1000 * 60);
	}
	
	public void setShiftEndTime(Date time) {
		ShiftEndTime = time;
		Worktime = (ShiftEndTime.getTime() - ShiftStartTime.getTime()) / (1000 * 60);
		//System.out.println("check == "+Worktime);
		Worktime = Worktime - SleptTime;
		//System.out.println("==="+Worktime);
	}
	public void setSleepTime(Date time){
		SleepStartTime = time;
	}
	
	public void setWakeUpTime(Date time){
		if(isNewWakeupStartTime){
			isNewWakeupStartTime = false;
			WakeupStartTime = time;
			SleptTime = (WakeupStartTime.getTime() - SleepStartTime.getTime())/(1000 * 60);
		}
		else {
			WakeupStartTime = time;
			SleptTime = SleptTime + ((WakeupStartTime.getTime() - SleepStartTime.getTime())/(1000 * 60));
		}
	}
}